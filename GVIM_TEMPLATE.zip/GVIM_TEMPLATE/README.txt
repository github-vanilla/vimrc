this is gvim template.
Put "Vim" dir on C drive and Connect Path to "Vim" dir.